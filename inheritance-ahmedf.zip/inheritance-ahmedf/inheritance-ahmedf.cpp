#ifndef CAR_CHASE_H_INCLUDED
#define CAR_CHASE_H_INCLUDED
#include <SFML/Graphics.hpp>

using namespace std;

class car {

protected:

    int maxspeed;
    int currentspeed;
    int acceleration:
    sf::Color color;
    int maxhealth;

public:

    car();

    //increase speed
    void speedup ();

    //Reduce speed
    void slowdown ();

    //Changes direction
    void switchlane (int lane);

};

class playercar : public car {

public:

    //sets a trap
    void settrap (int lane);

};

class policecar : public car {

public:

    //starts the siren
    void siren ();

    //damages player car
    void damagecar (car* c);
};


#endif // CAR_CHASE_H_INCLUDED
